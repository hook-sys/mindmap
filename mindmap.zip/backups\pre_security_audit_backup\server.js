const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const PORT = process.env.PORT || 3000;
const ROOT_DIR = __dirname;
const DATA_DIR = path.join(ROOT_DIR, 'data');
const USERS_DIR = path.join(DATA_DIR, 'users');

// Ensure data directories exist
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(USERS_DIR)) fs.mkdirSync(USERS_DIR, { recursive: true });

// Ensure default user exists
const defaultUserDir = path.join(USERS_DIR, 'Default User');
if (!fs.existsSync(defaultUserDir)) fs.mkdirSync(defaultUserDir, { recursive: true });

const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.js': 'application/javascript; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.zip': 'application/zip'
};

function sanitizeName(name) {
  if (!name || typeof name !== 'string') return 'User';
  return name.replace(/[^a-zA-Z0-9_\- ]/g, '').trim().substring(0, 50) || 'User';
}

function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
      if (body.length > 1e7) { // 10MB limit
        req.destroy();
        reject(new Error('Payload Too Large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  // CORS preflight
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const parsedUrl = new URL(req.url, `http://localhost:${PORT}`);
  const pathname = parsedUrl.pathname;

  // ================= API ROUTES =================
  if (pathname.startsWith('/api/')) {
    const username = sanitizeName(parsedUrl.searchParams.get('user') || 'Default User');
    const userFolder = path.join(USERS_DIR, username);

    if (!fs.existsSync(userFolder)) {
      fs.mkdirSync(userFolder, { recursive: true });
    }

    // 1. GET /api/users - List all users
    if (pathname === '/api/users' && req.method === 'GET') {
      try {
        const users = fs.readdirSync(USERS_DIR, { withFileTypes: true })
          .filter(dirent => dirent.isDirectory())
          .map(dirent => dirent.name);
        if (!users.includes('Default User')) users.unshift('Default User');
        return sendJson(res, 200, { users });
      } catch (e) {
        return sendJson(res, 500, { error: e.message });
      }
    }

    // 2. POST /api/users - Create/Switch user
    if (pathname === '/api/users' && req.method === 'POST') {
      try {
        const body = await parseJsonBody(req);
        const newUserName = sanitizeName(body.username);
        const newDir = path.join(USERS_DIR, newUserName);
        if (!fs.existsSync(newDir)) {
          fs.mkdirSync(newDir, { recursive: true });
        }
        return sendJson(res, 200, { success: true, username: newUserName });
      } catch (e) {
        return sendJson(res, 500, { error: e.message });
      }
    }

    // 3. GET /api/projects - List projects for a user
    if (pathname === '/api/projects' && req.method === 'GET') {
      try {
        const files = fs.readdirSync(userFolder).filter(f => f.endsWith('.json'));
        const projectList = [];

        for (const file of files) {
          try {
            const content = fs.readFileSync(path.join(userFolder, file), 'utf8');
            const data = JSON.parse(content);
            projectList.push({
              id: data.id || file.replace('.json', ''),
              title: data.title || 'Untitled Project',
              updatedAt: data.updatedAt || fs.statSync(path.join(userFolder, file)).mtimeMs,
              nodeCount: data.nodes ? Object.keys(data.nodes).length : 0
            });
          } catch (err) {
            console.error('Error reading project file:', file, err);
          }
        }

        projectList.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
        return sendJson(res, 200, { projects: projectList });
      } catch (e) {
        return sendJson(res, 500, { error: e.message });
      }
    }

    // 4. GET /api/projects/:id - Load specific project
    const projectMatch = pathname.match(/^\/api\/projects\/([a-zA-Z0-9_\-]+)$/);
    if (projectMatch && req.method === 'GET') {
      const projectId = projectMatch[1];
      const projectFile = path.join(userFolder, `${projectId}.json`);
      if (fs.existsSync(projectFile)) {
        try {
          const content = fs.readFileSync(projectFile, 'utf8');
          return sendJson(res, 200, JSON.parse(content));
        } catch (e) {
          return sendJson(res, 500, { error: e.message });
        }
      } else {
        return sendJson(res, 404, { error: 'Project not found' });
      }
    }

    // 5. POST /api/projects - Save or Update project
    if (pathname === '/api/projects' && req.method === 'POST') {
      try {
        const body = await parseJsonBody(req);
        const projectId = body.id || `proj_${Date.now()}`;
        const projectData = {
          id: projectId,
          title: body.title || 'Untitled Project',
          nodes: body.nodes || {},
          rootId: body.rootId || 'root',
          updatedAt: Date.now()
        };

        const projectFile = path.join(userFolder, `${projectId}.json`);
        fs.writeFileSync(projectFile, JSON.stringify(projectData, null, 2), 'utf8');
        return sendJson(res, 200, { success: true, project: projectData });
      } catch (e) {
        return sendJson(res, 500, { error: e.message });
      }
    }

    // 6. DELETE /api/projects/:id - Delete project
    if (projectMatch && req.method === 'DELETE') {
      const projectId = projectMatch[1];
      const projectFile = path.join(userFolder, `${projectId}.json`);
      if (fs.existsSync(projectFile)) {
        fs.unlinkSync(projectFile);
        return sendJson(res, 200, { success: true, deletedId: projectId });
      } else {
        return sendJson(res, 404, { error: 'Project not found' });
      }
    }

    return sendJson(res, 404, { error: 'API route not found' });
  }

  // ================= STATIC FILES =================
  let reqPath = decodeURI(pathname);
  if (reqPath === '/' || reqPath === '') {
    reqPath = '/index.html';
  }

  const filePath = path.join(ROOT_DIR, reqPath);

  if (!filePath.startsWith(ROOT_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('403 Forbidden');
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/html; charset=UTF-8' });
      res.end('<h1>404 Not Found</h1><p>File does not exist.</p>');
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': stats.size,
      'Cache-Control': 'no-cache'
    });

    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  });
});

server.listen(PORT, () => {
  const url = `http://localhost:${PORT}/`;
  console.log('\n=============================================');
  console.log(`🧠 MindMap Studio Dev Server is Running!`);
  console.log(`➜ Local:   ${url}`);
  console.log('➜ Multi-User & Projects API Active');
  console.log('➜ Press Ctrl+C to stop the server');
  console.log('=============================================\n');
});
